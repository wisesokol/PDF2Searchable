# SPDX-FileCopyrightText: 2023 geisserml <geisserml@gmail.com>
# SPDX-License-Identifier: Apache-2.0 OR BSD-3-Clause

# bindings.py and accompanying platform files are generated and emplaced automatically using pypdfium2 setup tooling - see autorelease/bindings.py for a tracked sample
from pypdfium2_raw.bindings import *
