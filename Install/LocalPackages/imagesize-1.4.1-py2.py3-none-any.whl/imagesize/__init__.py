__all__ = ["get", "getDPI", "__version__"]

__version__ = "1.4.1"

from .imagesize import get, getDPI
