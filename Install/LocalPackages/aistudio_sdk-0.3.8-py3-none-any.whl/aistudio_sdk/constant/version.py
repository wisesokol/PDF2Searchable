# !/usr/bin/env python3
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2023 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件注明版本号

Authors: xiangyiqing(xiangyiqing@baidu.com)
Date:    2023/07/24
"""
VERSION = "0.3.8"
